﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace MedicineTrackingApp.Models
{
    public class MedicineService
    {
        private readonly IHttpClientFactory httpClientFactory;

        public MedicineService(IHttpClientFactory httpClientFactory)
        {
            this.httpClientFactory = httpClientFactory;
        }
        public async Task<(bool IsSuccess, IEnumerable<Medicine> Medicine,string ErrorMessage)> GetMedicinesAsync()
        {
            var client = httpClientFactory.CreateClient("MedicineService");
            var response = await client.GetAsync("api/medicines");
            if(response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsByteArrayAsync();
                var options = new JsonSerializerOptions() { PropertyNameCaseInsensitive = true };
                var result = JsonSerializer.Deserialize<IEnumerable<Medicine>>(content, options);
                return (true, result, null);
            }
            return (false, null, null);

        }

    }
}
