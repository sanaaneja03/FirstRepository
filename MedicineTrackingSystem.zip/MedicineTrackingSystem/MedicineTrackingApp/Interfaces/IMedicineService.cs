﻿using MedicineTrackingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineTrackingApp.Interfaces
{
    public interface IMedicineService
    {
        Task<(bool IsSuccess, IEnumerable<Medicine> Medicine, string ErrorMessage)> GetMedicineAsync();

    }
}
