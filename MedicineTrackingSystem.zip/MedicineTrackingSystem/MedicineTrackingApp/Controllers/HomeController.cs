﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MedicineTrackingApp.Models;
using System.Net.Http;
using Microsoft.Extensions.Configuration;

using System.Text;
using System.Text.Json;

namespace MedicineTrackingApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration configuration;
        private readonly IHttpClientFactory httpClientFactory;
        private readonly string apiBaseUrl;

        public HomeController(ILogger<HomeController> logger,IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            this.configuration = configuration;
            this.httpClientFactory = httpClientFactory;
            apiBaseUrl = configuration.GetValue<string>("Services:Medicine");
        }
        [HttpGet]
        //public IActionResult Index()
        //{
        //    Medicine medicine = new Medicine();
        //    return View(medicine);

        //}
        [HttpGet]
        public ActionResult Medicine()
        {
            
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var client = httpClientFactory.CreateClient("MedicineService");
            var response = await client.GetAsync("api/medicines");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsByteArrayAsync();
                var options = new JsonSerializerOptions() { PropertyNameCaseInsensitive = true };
                var result = JsonSerializer.Deserialize<IEnumerable<Medicine>>(content, options);
                //var res = new { Medicine = result };
                return View(result);

            }
                    else
                    {
                        ModelState.Clear();
                        ModelState.AddModelError(string.Empty, "Username or Password is Incorrect");
                        return View();

                    }

                


            
        }

            public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
