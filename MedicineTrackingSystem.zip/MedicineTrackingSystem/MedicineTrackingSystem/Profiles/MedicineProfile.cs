﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineTrackingSystem.Profiles
{
    public class MedicineProfile :AutoMapper.Profile
    {
        public MedicineProfile()
        {
            CreateMap<Db.Medicine, Models.Medicine>();
        }
    }
}
