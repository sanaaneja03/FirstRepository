﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineTrackingSystem.Db
{
    public class Medicine
    {
        [Key]
        public string FullName { get; set; }
        public string Brand { get; set; }
        public decimal Price { get; set; } //upto 2 decimal
        public int Quantity { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Notes { get; set; }
    }
}
