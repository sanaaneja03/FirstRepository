﻿using AutoMapper;
using MedicineTrackingSystem.Db;
using MedicineTrackingSystem.Interfaces;
using MedicineTrackingSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineTrackingSystem.Providers
{
    public class MedicinesProvider : IMedicinesProvider
    {
        private readonly MedicineDbContext dbContext;
        private readonly ILogger<MedicinesProvider> logger;
        private readonly IMapper mapper;

        public MedicinesProvider(MedicineDbContext dbContext,ILogger<MedicinesProvider> logger,IMapper mapper)
        {
            this.dbContext = dbContext;
            this.logger = logger;
            this.mapper = mapper;
            SeedData();
        }
        public void SeedData()
        {
            if(!dbContext.Medicines.Any())
            {
                dbContext.Medicines.Add(new Db.Medicine()
                {
                    FullName = "Paracetamol",
                    Brand = "Abott",
                    Price = 20,
                    Quantity = 20,
                    ExpiryDate = new DateTime(2020,12,12),
                    Notes = "For Fever"
                });
                dbContext.SaveChanges();
            }
        }
        public async Task<(bool IsSuccess, IEnumerable<Models.Medicine> Medicine, string ErrorMessage)> GetMedicinesAsync()
        {
            try
            {
                var medicines = await dbContext.Medicines.ToListAsync();
                if(medicines!=null && medicines.Any())
                {
                    var result = mapper.Map<IEnumerable<Db.Medicine>, IEnumerable<Models.Medicine>>(medicines);
                    return (true, result, null);
                }
                else
                {
                    return (false, null, "NotFound");
                }
            }
            catch(Exception ex)
            {
                logger?.LogError(ex.ToString());
                return (false, null, ex.Message);
            }
        }
    }
}
