﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicineTrackingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace MedicineTrackingSystem.Controllers
{
    [ApiController]
    [Route("api/medicines")]
    public class MedicinesController : ControllerBase
    {
        private readonly IMedicinesProvider medicinesProvider;

        public MedicinesController(IMedicinesProvider medicinesProvider)
        {
            this.medicinesProvider = medicinesProvider;
        }
        public async Task<IActionResult> GetMedicinesAsync()
        {
            var result = await medicinesProvider.GetMedicinesAsync();
            if(result.IsSuccess)
            {
                return Ok(result.Medicine);
            }
            return NotFound();
        }
    }
}
