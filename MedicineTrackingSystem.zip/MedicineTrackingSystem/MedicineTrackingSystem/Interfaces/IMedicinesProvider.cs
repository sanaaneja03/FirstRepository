﻿using MedicineTrackingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineTrackingSystem.Interfaces
{
    public interface IMedicinesProvider
    {
        Task<(bool IsSuccess, IEnumerable<Medicine> Medicine, string ErrorMessage)> GetMedicinesAsync();
    }
}
